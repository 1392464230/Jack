package com.example.u022.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    ArrayAdapter<String> adapter;
    String[] ListItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mListView =(ListView)findViewById(R.id.Information);
        String[] strs = new String []{"Area", "Volume", "Circumference", "Perimeter", "Pythagorean", "Area_Square", "Area_Rectangle"};

        adapter = new ArrayAdapter(MainActivity.this, R.layout.activity_listview, strs);
        mListView.setAdapter(adapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent();
                switch (position){
                    case 0:
                        i = new Intent(MainActivity.this, Area.class);
                        break;
                    case 1:
                        i = new Intent(MainActivity.this, Volume.class);
                        break;
                    case 2:
                        i = new Intent(MainActivity.this, Circumference.class);
                        break;
                    case 3:
                        i = new Intent(MainActivity.this, Perimeter.class);
                        break;
                    case 4:
                        i = new Intent(MainActivity.this, Pythagorean.class);
                        break;
                    case 5:
                        i = new Intent(MainActivity.this, Area_Square.class);
                        break;
                    case 6:
                        i = new Intent(MainActivity.this, Area_Rectangle.class);
                        break;
                }
                startActivity(i);
            }
        });

    }

}
