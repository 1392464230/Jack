package com.example.u022.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Area_Square extends AppCompatActivity {
    private Button calculate_Button, back_Button;
    private EditText side;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area__square);

        calculate_Button = (Button) findViewById(R.id.calculate_Button);
        back_Button = (Button) findViewById(R.id.back_Button);
        side = (EditText) findViewById(R.id.side);

        calculate_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                double R2 = Double.parseDouble(side.getText().toString());
                Toast.makeText(Area_Square.this,
                        "Area of a Square: " + R2 * R2,Toast.LENGTH_LONG).show();
            }
        });
    }
}
