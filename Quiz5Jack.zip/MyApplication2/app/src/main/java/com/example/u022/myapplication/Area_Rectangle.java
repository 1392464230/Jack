package com.example.u022.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Area_Rectangle extends AppCompatActivity {
    private Button calculate_Button, back_Button;
    private EditText length, width;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area__rectangle);

        calculate_Button = (Button) findViewById(R.id.calculate_Button);
        back_Button = (Button) findViewById(R.id.back_Button);
        length = (EditText) findViewById(R.id.length);
        width = (EditText) findViewById(R.id.width);

        calculate_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                double R2 = Double.parseDouble(length.getText().toString());
                double R3 = Double.parseDouble(width.getText().toString());
                Toast.makeText(Area_Rectangle.this,
                        "Area of a Circle: " + R2 * R3,Toast.LENGTH_LONG).show();
            }
        });

        back_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
               finish();
            }
        });
    }
}
