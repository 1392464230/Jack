package com.example.u022.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Volume extends AppCompatActivity {
    private Button calculate_Button, back_Button;
    private EditText r, h;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume);

        calculate_Button = (Button) findViewById(R.id.calculate_Button);
        back_Button = (Button) findViewById(R.id.back_Button);
        r = (EditText) findViewById(R.id.r);
        h = (EditText) findViewById(R.id.h);

        calculate_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                double R2 = Double.parseDouble(r.getText().toString());
                double R3 = Double.parseDouble(h.getText().toString());
                Toast.makeText(Volume.this,
                        "Area of a Circle: " + 3.14 * R2 * R2 * R3,Toast.LENGTH_LONG).show();
            }
        });
    }
}
