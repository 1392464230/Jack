package com.example.u022.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Circumference extends AppCompatActivity {
    private Button calculate_Button, back_Button;
    private EditText r;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circumference);

        calculate_Button = (Button) findViewById(R.id.calculate_Button);
        back_Button = (Button) findViewById(R.id.back_Button);
        r = (EditText) findViewById(R.id.r);

        calculate_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                double R2 = Double.parseDouble(r.getText().toString());
                Toast.makeText(Circumference.this,
                        "Area of a Circle: " + 6.18 * R2,Toast.LENGTH_LONG).show();
            }
        });
    }
}
