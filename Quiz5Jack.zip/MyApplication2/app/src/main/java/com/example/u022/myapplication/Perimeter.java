package com.example.u022.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Perimeter extends AppCompatActivity {
    private Button calculate_Button, back_Button;
    private EditText side1, side2, side3, side4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perimeter);

        calculate_Button = (Button) findViewById(R.id.calculate_Button);
        back_Button = (Button) findViewById(R.id.back_Button);
        side1 = (EditText) findViewById(R.id.side1);
        side2 = (EditText) findViewById(R.id.side2);
        side3 = (EditText) findViewById(R.id.side3);
        side4 = (EditText) findViewById(R.id.side4);

        calculate_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                double R2 = Double.parseDouble(side1.getText().toString());
                double R3 = Double.parseDouble(side2.getText().toString());
                double R4 = Double.parseDouble(side3.getText().toString());
                double R5 = Double.parseDouble(side4.getText().toString());
                Toast.makeText(Perimeter.this,
                        "Area of a Circle: " + R2 + R3 + R4 + R5,Toast.LENGTH_LONG).show();
            }
        });
    }
}
