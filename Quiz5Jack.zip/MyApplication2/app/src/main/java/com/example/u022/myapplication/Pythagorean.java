package com.example.u022.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Pythagorean extends AppCompatActivity {
    private Button calculate_Button, back_Button;
    private EditText a, b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pythagorean);

        calculate_Button = (Button) findViewById(R.id.calculate_Button);
        back_Button = (Button) findViewById(R.id.back_Button);
        a = (EditText) findViewById(R.id.a);
        b = (EditText) findViewById(R.id.b);

        calculate_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                double R2 = Double.parseDouble(a.getText().toString());
                double R3 = Double.parseDouble(b.getText().toString());
                Toast.makeText(Pythagorean.this,
                        "Area of a Circle: " + Math.sqrt(R2 * R3),Toast.LENGTH_LONG).show();
            }
        });
    }
}
